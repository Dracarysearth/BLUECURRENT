# BLUECURRENT

**Discover Liquidity. Trade Smarter.**

A swap terminal and liquidity radar on **GIWA Sepolia (chain 91342)**, built with the official
[Ammora SDK](https://www.npmjs.com/package/@ammora-protocol/sdk) (`@ammora-protocol/sdk@0.3.9`) for the
Ammora Season 2 Builder Mission. React 19 + Vite + TypeScript + viem.

> Independent community-built application powered by the Ammora SDK on GIWA. Testnet software, not audited.
> Never use real funds. Every transaction is signed by your own wallet; the app never asks for keys or seed phrases.

## Pages

| Route | What it does |
| --- | --- |
| `#/exchange` | Swap terminal (buy WETH → token, sell token → WETH) with live SDK quote, slippage, minimum received, approvals, simulation, confirmation modal, receipt check and explorer link. Route preview panel beside it. |
| `#/markets` | Launch curves discovered through Ammora's Data API; token name/symbol/decimals read from the chain. |
| `#/market?curve=0x…` | Market detail: observed curve state, quote-based estimates, risk flags, recent `Swap` events. |
| `#/liquidity` | Liquidity radar: same insight panel with the SDK deployment catalog and check. |
| `#/portfolio` | ETH, WETH and launch-token balances actually read from the chain, WETH wrap helper, recent trades. |
| `#/activity` | Trades made through this app; status and received amount come from the real receipt. |

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run typecheck  # tsc --noEmit
npm run build
npm run preview
```

Node.js 22+ (24 works). Copy `.env.example` to `.env` only if you want to override defaults.

## Environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `VITE_GIWA_RPC_URL` | `https://sepolia-rpc.giwa.io` | JSON-RPC endpoint |
| `VITE_GIWA_EXPLORER_URL` | `https://sepolia-explorer.giwa.io` | Explorer links |
| `VITE_AMMORA_DATA_API` | `https://ammora-giwa-sepolia-data.fly.dev` | Launch discovery |
| `VITE_REQUIRE_VERIFICATION` | `true` | Disable swaps unless `verifyAmmoraV4CoreAtBlock` passes |

## How the SDK is used (all in `src/services/ammora.ts`)

1. `giwaSepoliaAutoRouteDeployment` + `verifyAmmoraV4CoreAtBlock`: deployment check before trading.
2. `AmmoraDataApiClient.getLaunches`: discovery of supported launch-curve markets.
3. `AmmoraV4LaunchCurveClient.getStateAtBlock`: live market state.
4. `quoteExactInputAtBlock` + `classifyAmmoraV4ExactInputFill`: exact-input quote and final-fill handling.
5. `planSwapExactInput`: slippage-bound, deadline-bound swap transaction.
6. Approvals: SDK `approvalRequirements` when present, otherwise an allowance check. Exact-amount approvals only.
7. Simulation (`eth_call`) right before signing, wallet signature, receipt verification, output reconciled from ERC-20 `Transfer` logs.

Execution amounts are `bigint` everywhere; floats are used only for display. Config #6 is never used for launches
(this app does not create launches). If a market cannot be quoted, the UI shows an unavailable state; a trade is never simulated as successful.

## Deploy

1. Push to GitHub (repo `Dracarysearth/BLUECURRENT`).
2. Vercel → *Add New Project* → import the repo. Framework: Vite (auto-detected). Build `npm run build`, output `dist`.
3. Deploy. Environment variables are optional.

## Known limitations

- Trades go through **launch-curve markets** only. Graduated pool trading (`AmmoraSwapClient`) and ALMM/ARL analytics are not implemented, and the UI says so instead of faking them.
- The SDK adapter was written against the SDK's public README and public builder repos; exact constructor and return shapes are read defensively. If `npm run typecheck` or the first live quote reports a shape mismatch, fix it in `src/services/ammora.ts` (spots are marked `VERIFY`).
- Activity history is stored in the browser (`localStorage`), per wallet.
- The public GIWA RPC can be slow and limits `eth_getLogs` ranges (~10k blocks).
