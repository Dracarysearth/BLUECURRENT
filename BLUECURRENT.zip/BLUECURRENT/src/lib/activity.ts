import { parseEventLogs, type Address, type Hex } from "viem";
import { erc20Abi } from "./abi";
import { publicClient } from "./chain";
import type { ActivityRecord } from "../types";

const key = (a: Address) => `bc:activity:${a.toLowerCase()}`;

export function loadActivity(account: Address): ActivityRecord[] {
  try {
    return JSON.parse(localStorage.getItem(key(account)) ?? "[]");
  } catch {
    return [];
  }
}

export function upsertActivity(rec: ActivityRecord) {
  const all = loadActivity(rec.account).filter((r) => r.hash !== rec.hash);
  all.unshift(rec);
  try {
    localStorage.setItem(key(rec.account), JSON.stringify(all.slice(0, 100)));
  } catch {}
}

/** Re-check pending records against real receipts and reconcile the actual output amount. */
export async function reconcile(rec: ActivityRecord, outToken: Address): Promise<ActivityRecord> {
  try {
    const r = await publicClient.getTransactionReceipt({ hash: rec.hash as Hex });
    if (r.status !== "success") return { ...rec, status: "failed" };
    const logs = parseEventLogs({ abi: erc20Abi, eventName: "Transfer", logs: r.logs });
    const received = logs
      .filter((l) => l.address.toLowerCase() === outToken.toLowerCase() && l.args.to.toLowerCase() === rec.account.toLowerCase())
      .reduce((s, l) => s + l.args.value, 0n);
    return { ...rec, status: "confirmed", amountOut: received.toString() };
  } catch {
    return rec; // still pending / receipt not found yet
  }
}
