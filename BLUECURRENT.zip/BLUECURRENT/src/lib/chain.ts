import { createPublicClient, defineChain, http, type Address } from "viem";

const env = import.meta.env;

export const RPC_URL: string = env.VITE_GIWA_RPC_URL ?? "https://sepolia-rpc.giwa.io";
export const EXPLORER_URL: string = (env.VITE_GIWA_EXPLORER_URL ?? "https://sepolia-explorer.giwa.io").replace(/\/$/, "");
export const REQUIRE_VERIFICATION: boolean = (env.VITE_REQUIRE_VERIFICATION ?? "true") !== "false";

/** WETH is the quote token of Ammora V4 launch curves on GIWA Sepolia (OP-stack predeploy). */
export const WETH: Address = "0x4200000000000000000000000000000000000006";

export const giwaSepolia = defineChain({
  id: 91342,
  name: "GIWA Sepolia",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: { default: { http: [RPC_URL] } },
  blockExplorers: { default: { name: "GIWA Explorer", url: EXPLORER_URL } },
  // Canonical Multicall3 address; needed by viem for unknown chains.
  contracts: { multicall3: { address: "0xcA11bde05977b3631167028862bE2a173976CA11" } },
  testnet: true,
});

export const publicClient = createPublicClient({
  chain: giwaSepolia,
  transport: http(RPC_URL, { retryCount: 2, timeout: 30_000 }),
  batch: { multicall: true },
});

export const txUrl = (hash: string) => `${EXPLORER_URL}/tx/${hash}`;
export const addressUrl = (addr: string) => `${EXPLORER_URL}/address/${addr}`;
