import { formatUnits, parseUnits } from "viem";

export const short = (a?: string, n = 4) => (a ? `${a.slice(0, n + 2)}…${a.slice(-n)}` : "—");

/** Human readable token amount from a bigint. Never goes through Number for the integer part. */
export function fmtAmount(v: bigint | undefined, decimals: number, maxFrac = 6): string {
  if (v === undefined) return "—";
  const [i, f = ""] = formatUnits(v, decimals).split(".");
  const int = i.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const frac = f.slice(0, maxFrac).replace(/0+$/, "");
  return frac ? `${int}.${frac}` : int;
}

/** Parse user input to bigint. Returns undefined for empty / invalid / too many decimals. */
export function parseAmount(input: string, decimals: number): bigint | undefined {
  const s = input.trim();
  if (!/^\d*\.?\d*$/.test(s) || s === "" || s === ".") return undefined;
  const [, f = ""] = s.split(".");
  if (f.length > decimals) return undefined;
  try {
    return parseUnits(s, decimals);
  } catch {
    return undefined;
  }
}

/** minimum received = out * (10000 - bps) / 10000, BigInt only. */
export const applySlippage = (out: bigint, bps: number) => (out * BigInt(10_000 - bps)) / 10_000n;

export const ago = (ms: number) => {
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

/** JSON.stringify that survives bigint. */
export const safeJson = (v: unknown, space = 2) =>
  JSON.stringify(v, (_k, x) => (typeof x === "bigint" ? x.toString() : x), space);

export const isAddress = (s: string): s is `0x${string}` => /^0x[a-fA-F0-9]{40}$/.test(s);
