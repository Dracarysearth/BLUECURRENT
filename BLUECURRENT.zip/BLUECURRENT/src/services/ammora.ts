/**
 * Ammora SDK adapter — the only file that touches @ammora-protocol/sdk.
 *
 * Function names used here were confirmed from the SDK's public README and from
 * public builder repos for 0.3.9:
 *   giwaSepoliaAutoRouteDeployment, verifyAmmoraV4CoreAtBlock, AmmoraDataApiClient,
 *   AmmoraV4LaunchCurveClient (getStateAtBlock, quoteExactInputAtBlock, planSwapExactInput),
 *   classifyAmmoraV4ExactInputFill.
 * Exact constructor/return shapes are read defensively (see `pick`). Anything marked VERIFY
 * should be checked against https://docs.ammora.org once `npm install` has run
 * (`node_modules/@ammora-protocol/sdk/dist/*.d.ts` has the real types).
 */
import * as sdk from "@ammora-protocol/sdk";
import type { Address, Hex } from "viem";
import { publicClient } from "../lib/chain";
import { erc20Abi } from "../lib/abi";
import type { Approval, Market } from "../types";

const S = sdk as any;

export const DATA_API_URL: string =
  import.meta.env.VITE_AMMORA_DATA_API ?? "https://ammora-giwa-sepolia-data.fly.dev";
export const CHAIN_ID = 91_342n;

const pick = (o: any, keys: string[]): any => {
  for (const k of keys) if (o && o[k] !== undefined && o[k] !== null) return o[k];
  return undefined;
};
const asBig = (v: any): bigint | undefined => {
  try {
    if (typeof v === "bigint") return v;
    if (typeof v === "string" && /^\d+$/.test(v)) return BigInt(v);
    if (typeof v === "number" && Number.isFinite(v)) return BigInt(Math.trunc(v));
  } catch {}
  return undefined;
};
const asAddr = (v: any): Address | undefined => {
  const a = typeof v === "object" && v ? pick(v, ["address", "id"]) : v;
  return typeof a === "string" && /^0x[a-fA-F0-9]{40}$/.test(a) ? (a as Address) : undefined;
};
export const errMsg = (e: any): string => String(e?.shortMessage ?? e?.message ?? e).split("\n")[0].slice(0, 280);

/* ---------- 1. deployment ---------- */

export const getCatalog = (): unknown => S.giwaSepoliaAutoRouteDeployment ?? null;

export type Verification =
  | { status: "ok"; block: bigint }
  | { status: "failed" | "unavailable"; message: string };

/** Step 1 of the lifecycle: verify the deployment before anything else. */
export async function verifyDeployment(): Promise<Verification> {
  const deployment = getCatalog();
  if (!deployment || typeof S.verifyAmmoraV4CoreAtBlock !== "function")
    return { status: "unavailable", message: "SDK catalog or verifyAmmoraV4CoreAtBlock not exported by this SDK build." };
  try {
    const id = await publicClient.getChainId();
    if (id !== 91342) return { status: "failed", message: `RPC reports chain ${id}, expected 91342.` };
    const block = await publicClient.getBlockNumber();
    try {
      await S.verifyAmmoraV4CoreAtBlock(publicClient, deployment, block); // VERIFY argument order
    } catch (first) {
      await S.verifyAmmoraV4CoreAtBlock({ client: publicClient, publicClient, deployment, blockNumber: block }).catch(() => {
        throw first;
      });
    }
    return { status: "ok", block };
  } catch (e) {
    return { status: "failed", message: errMsg(e) };
  }
}

/* ---------- 2. discovery ---------- */

export async function fetchMarkets(limit = 40): Promise<{ markets: Market[]; dropped: number }> {
  const api = new S.AmmoraDataApiClient(DATA_API_URL);
  const res: any = await api.getLaunches({ chainId: CHAIN_ID });
  const rows: any[] = Array.isArray(res) ? res : pick(res, ["launches", "items", "data", "results"]) ?? [];
  const markets: Market[] = [];
  let dropped = 0;
  for (const l of rows) {
    const token = asAddr(pick(l, ["token", "tokenAddress", "baseToken", "base"]));
    const curve = asAddr(pick(l, ["curve", "curveAddress", "pool", "poolAddress", "launchPool", "launchPoolAddress"]));
    if (!token || !curve) {
      dropped++;
      continue;
    }
    const tObj = pick(l, ["token", "baseToken"]);
    const ts = asBig(pick(l, ["createdAt", "timestamp", "blockTimestamp"]));
    markets.push({
      token,
      curve,
      name: pick(l, ["name"]) ?? (typeof tObj === "object" ? tObj?.name : undefined),
      symbol: pick(l, ["symbol"]) ?? (typeof tObj === "object" ? tObj?.symbol : undefined),
      status: pick(l, ["status", "state"]),
      createdAt: ts ? Number(ts) * (ts < 10_000_000_000n ? 1000 : 1) : undefined,
      raw: l,
    });
  }
  markets.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
  return { markets: markets.slice(0, limit), dropped };
}

export async function readTokenMeta(token: Address) {
  const [name, symbol, decimals] = await publicClient.multicall({
    allowFailure: true,
    contracts: [
      { address: token, abi: erc20Abi, functionName: "name" },
      { address: token, abi: erc20Abi, functionName: "symbol" },
      { address: token, abi: erc20Abi, functionName: "decimals" },
    ],
  });
  return {
    name: name.status === "success" ? (name.result as string) : undefined,
    symbol: symbol.status === "success" ? (symbol.result as string) : undefined,
    decimals: decimals.status === "success" ? Number(decimals.result) : 18,
  };
}

/* ---------- 3. live state, quote, plan ---------- */

const curveClient = (curve: Address) => new S.AmmoraV4LaunchCurveClient(publicClient, curve); // VERIFY constructor

export async function readCurveState(curve: Address) {
  const block = await publicClient.getBlockNumber();
  const c = curveClient(curve);
  const state = typeof c.getStateAtBlock === "function" ? await c.getStateAtBlock(block) : await c.getState();
  return { block, state: state as Record<string, unknown> };
}

export type QuoteResult = {
  block: bigint;
  fetchedAt: number;
  amountOut?: bigint;
  priceImpactBps?: number;
  feeAmount?: bigint;
  fill?: { allowPartialFill: boolean; kind?: string };
  raw: unknown;
};

/** baseForQuote=true → input is the launch token (sell). false → input is WETH (buy). */
export async function quoteExactIn(curve: Address, amountIn: bigint, baseForQuote: boolean): Promise<QuoteResult> {
  const block = await publicClient.getBlockNumber();
  const c = curveClient(curve);
  const raw = await c.quoteExactInputAtBlock(amountIn, baseForQuote, block);
  let fill: QuoteResult["fill"];
  try {
    const f = S.classifyAmmoraV4ExactInputFill(raw, baseForQuote);
    fill = { allowPartialFill: !!f?.allowPartialFill, kind: f?.kind ?? f?.classification };
  } catch {}
  const impact = pick(raw, ["priceImpactBps", "priceImpactBp"]);
  return {
    block,
    fetchedAt: Date.now(),
    amountOut: asBig(pick(raw, ["amountOut", "outputAmount", "amountOutIncluded", "netAmountOut", "expectedOut"])),
    priceImpactBps: impact !== undefined ? Number(impact) : undefined,
    feeAmount: asBig(pick(raw, ["fee", "feeAmount", "totalFee"])),
    fill,
    raw,
  };
}

export type SwapPlan = {
  to: Address;
  data: Hex;
  value: bigint;
  approvals: Approval[];
  minimumOut?: bigint;
  deadline: bigint;
  sdkStatus?: string;
  raw: unknown;
};

export async function planSwap(a: {
  curve: Address;
  amountIn: bigint;
  baseForQuote: boolean;
  allowPartialFill: boolean;
  slippageBps: number;
  recipient: Address;
  deadlineMinutes?: number;
}): Promise<SwapPlan> {
  const deadline = BigInt(Math.floor(Date.now() / 1000) + (a.deadlineMinutes ?? 20) * 60);
  const raw: any = await curveClient(a.curve).planSwapExactInput({
    includedAmountIn: a.amountIn,
    baseForQuote: a.baseForQuote,
    allowPartialFill: a.allowPartialFill,
    slippageBps: a.slippageBps,
    recipient: a.recipient,
    deadline,
  });
  const tx = pick(raw, ["transaction", "tx", "request"]) ?? raw;
  const to = asAddr(tx?.to) ?? asAddr(raw?.to);
  const data: Hex | undefined = tx?.data ?? raw?.data;
  if (!to || !data) throw new Error("SDK plan did not contain a transaction (to/data). Plan shape needs VERIFY in services/ammora.ts.");
  const reqs: any[] = pick(raw, ["approvalRequirements"]) ?? (raw?.approvalRequirement ? [raw.approvalRequirement] : []);
  const approvals = reqs
    .map((r) => ({
      token: asAddr(pick(r, ["token", "tokenAddress"])),
      spender: asAddr(pick(r, ["spender", "spenderAddress"])),
      amount: asBig(pick(r, ["amount", "requiredAmount", "minimumAllowance"])),
    }))
    .filter((r): r is Approval => !!r.token && !!r.spender && r.amount !== undefined);
  return {
    to,
    data,
    value: asBig(tx?.value) ?? 0n,
    approvals,
    minimumOut: asBig(pick(raw, ["minimumAmountOut", "minAmountOut", "amountOutMinimum", "minimumOut"])),
    deadline,
    sdkStatus: typeof raw?.status === "string" ? raw.status : undefined,
    raw,
  };
}

/* ---------- risk policy surfaced by the SDK, if any ---------- */
export function extractWarnings(...objs: unknown[]): string[] {
  const out: string[] = [];
  for (const o of objs as any[]) {
    for (const k of ["warnings", "riskWarnings", "routeRiskPolicy", "risks"]) {
      const v = o?.[k];
      if (Array.isArray(v)) v.forEach((x) => out.push(typeof x === "string" ? x : x?.message ?? JSON.stringify(x, (_a, b) => (typeof b === "bigint" ? b.toString() : b))));
      else if (typeof v === "string") out.push(v);
    }
  }
  return out;
}

/* ---------- 4. recent curve trades (verified chain events) ---------- */

export type SwapEvent = { hash: Hex; block: bigint; args: Record<string, unknown> };

/** Reads the curve's own `Swap` events from the SDK ABI. The public RPC caps getLogs ranges at ~10k blocks. */
export async function readRecentSwaps(curve: Address, span = 9_000n): Promise<SwapEvent[]> {
  const abi: any[] | undefined = S.ammoraLaunchPoolV4Abi; // VERIFY export name
  const ev = abi?.find((x) => x.type === "event" && x.name === "Swap");
  if (!ev) throw new Error("Swap event ABI not found in the SDK build.");
  const head = await publicClient.getBlockNumber();
  const logs = await publicClient.getLogs({ address: curve, event: ev, fromBlock: head > span ? head - span : 0n, toBlock: head });
  return logs
    .slice(-20)
    .reverse()
    .map((l: any) => ({ hash: l.transactionHash as Hex, block: l.blockNumber as bigint, args: (l.args ?? {}) as Record<string, unknown> }));
}
