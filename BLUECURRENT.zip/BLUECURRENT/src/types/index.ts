import type { Address, Hex } from "viem";

export type Market = {
  token: Address;
  curve: Address;
  name?: string;
  symbol?: string;
  decimals?: number;
  status?: string | number;
  createdAt?: number;
  raw: unknown;
};

export type ActivityRecord = {
  hash: Hex;
  account: Address;
  curve: Address;
  token: Address;
  symbol: string;
  direction: "buy" | "sell";
  amountIn: string; // raw bigint as string
  amountInDecimals: number;
  amountInSymbol: string;
  amountOut?: string; // reconciled from receipt
  amountOutDecimals: number;
  amountOutSymbol: string;
  createdAt: number;
  status: "pending" | "confirmed" | "failed";
};

export type Approval = { token: Address; spender: Address; amount: bigint };
