import { useEffect } from "react";
import { Footer } from "./components/Footer";
import { Header } from "./components/Header";
import { Hero, Overview } from "./components/Overview";
import { Notice } from "./components/ui";
import { useRoute } from "./hooks/useRoute";
import { useVerification } from "./hooks/useChainData";
import { useWallet } from "./hooks/useWallet";
import { REQUIRE_VERIFICATION } from "./lib/chain";
import Activity from "./pages/Activity";
import Exchange from "./pages/Exchange";
import Liquidity from "./pages/Liquidity";
import MarketDetail from "./pages/MarketDetail";
import Markets from "./pages/Markets";
import Portfolio from "./pages/Portfolio";

export default function App() {
  const route = useRoute();
  const w = useWallet();
  const ver = useVerification();
  useEffect(() => window.scrollTo(0, 0), [route.path]);

  let page;
  switch (route.path) {
    case "/markets": page = <Markets />; break;
    case "/market": page = <MarketDetail route={route} />; break;
    case "/liquidity": page = <Liquidity route={route} />; break;
    case "/portfolio": page = <Portfolio />; break;
    case "/activity": page = <Activity />; break;
    default: page = (<><Hero /><Exchange route={route} /><Overview /></>);
  }

  return (
    <>
      <Header path={route.path === "/market" ? "/markets" : route.path === "/exchange" ? "/exchange" : route.path} />
      <main className="main">
        {w.error && <Notice tone="bad">{w.error}</Notice>}
        {!w.hasProvider && <Notice tone="warn">No browser wallet detected. You can browse markets; install MetaMask to trade.</Notice>}
        {w.wrongNetwork && <Notice tone="warn">Your wallet is on a different network. <button className="linkbtn" onClick={w.switchNetwork}>Switch to GIWA Sepolia</button></Notice>}
        {ver !== "pending" && ver.status !== "ok" && <Notice tone="warn">SDK deployment check {ver.status}: {ver.message} {REQUIRE_VERIFICATION ? "Trading stays disabled until it passes." : "Trading is allowed because VITE_REQUIRE_VERIFICATION=false."}</Notice>}
        {page}
      </main>
      <Footer />
    </>
  );
}
