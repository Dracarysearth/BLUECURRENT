import { useCallback, useEffect, useState } from "react";
import { useMarkets } from "../hooks/useChainData";
import { useWallet } from "../hooks/useWallet";
import { go } from "../hooks/useRoute";
import { erc20Abi, wethAbi } from "../lib/abi";
import { publicClient, WETH } from "../lib/chain";
import { loadActivity } from "../lib/activity";
import { fmtAmount, parseAmount } from "../lib/format";
import { errMsg } from "../services/ammora";
import { AddrLink, Empty, Notice, Row, Spinner, Tag, TxLink } from "../components/ui";

type Holding = { symbol: string; token: `0x${string}`; curve: `0x${string}`; balance: bigint; decimals: number };

export default function Portfolio() {
  const w = useWallet();
  const { markets } = useMarkets();
  const [eth, setEth] = useState<bigint>();
  const [weth, setWeth] = useState<bigint>();
  const [holdings, setHoldings] = useState<Holding[]>();
  const [err, setErr] = useState<string>();
  const [wrap, setWrap] = useState("");
  const [msg, setMsg] = useState<{ t: string; tone: "info" | "good" | "bad" }>();

  const load = useCallback(async () => {
    if (!w.account) return;
    setErr(undefined);
    try {
      const [e, wb] = await Promise.all([
        publicClient.getBalance({ address: w.account }),
        publicClient.readContract({ address: WETH, abi: erc20Abi, functionName: "balanceOf", args: [w.account] }),
      ]);
      setEth(e); setWeth(wb);
      const res = await publicClient.multicall({
        allowFailure: true,
        contracts: markets.map((m) => ({ address: m.token, abi: erc20Abi, functionName: "balanceOf" as const, args: [w.account!] })),
      });
      setHoldings(
        markets.flatMap((m, i) => {
          const r = res[i];
          return r.status === "success" && (r.result as bigint) > 0n
            ? [{ symbol: m.symbol ?? "?", token: m.token, curve: m.curve, balance: r.result as bigint, decimals: m.decimals ?? 18 }]
            : [];
        }),
      );
    } catch (e) {
      setErr(errMsg(e));
    }
  }, [w.account, markets]);
  useEffect(() => { load(); }, [load]);

  async function doWrap() {
    const v = parseAmount(wrap, 18);
    if (!w.walletClient || !w.account || !v) return;
    try {
      setMsg({ t: "Confirm the wrap in your wallet…", tone: "info" });
      const hash = await w.walletClient.writeContract({ address: WETH, abi: wethAbi, functionName: "deposit", value: v, account: w.account, chain: w.walletClient.chain });
      const r = await publicClient.waitForTransactionReceipt({ hash });
      setMsg({ t: r.status === "success" ? "Wrapped. Your WETH balance is updated." : "Wrap transaction failed.", tone: r.status === "success" ? "good" : "bad" });
      setWrap(""); load();
    } catch (e) {
      setMsg({ t: errMsg(e), tone: "bad" });
    }
  }

  if (!w.account) return <Empty title="Connect your wallet">Your GIWA balances and positions appear here once a wallet is connected.<br /><button className="btn primary" onClick={w.connect}>Connect wallet</button></Empty>;
  const recent = loadActivity(w.account).slice(0, 5);

  return (
    <>
      <div className="page-head"><h1>Portfolio</h1><p className="muted"><AddrLink a={w.account} /> · only balances read from the chain are shown.</p></div>
      {err && <Notice tone="bad">Could not read balances: {err}</Notice>}
      <div className="card wide">
        <h3>Balances</h3>
        <Row k="ETH (native, gas)" v={eth === undefined ? <Spinner /> : `${fmtAmount(eth, 18)} ETH`} />
        <Row k="WETH (buy currency)" v={weth === undefined ? <Spinner /> : `${fmtAmount(weth, 18)} WETH`} />
        <div className="wrapbox">
          <input inputMode="decimal" placeholder="ETH to wrap" value={wrap} onChange={(e) => setWrap(e.target.value)} aria-label="ETH to wrap" />
          <button className="btn ghost sm" disabled={!parseAmount(wrap, 18) || w.wrongNetwork} onClick={doWrap}>Wrap ETH → WETH</button>
        </div>
        {msg && <Notice tone={msg.tone}>{msg.t}</Notice>}
      </div>
      <div className="card wide">
        <h3>Market positions <Tag tone="blue">launch tokens you hold</Tag></h3>
        {holdings === undefined ? <Spinner label="Scanning discovered markets…" /> : !holdings.length ? <Empty title="No launch-token balances">Tokens from the discovered markets that you hold will be listed here.</Empty> :
          holdings.map((h) => <Row key={h.token} k={h.symbol} v={<>{fmtAmount(h.balance, h.decimals)} <button className="linkbtn" onClick={() => go("/exchange", { curve: h.curve })}>Trade</button></>} />)}
        <p className="muted small">Only tokens from the {markets.length} discovered markets are checked; other ERC-20s are not listed.</p>
      </div>
      <div className="card wide">
        <h3>Recent transactions</h3>
        {!recent.length ? <Empty title="No trades from this app yet" /> : recent.map((r) => <Row key={r.hash} k={`${r.direction} ${r.symbol}`} v={<><Tag tone={r.status === "confirmed" ? "good" : r.status === "failed" ? "bad" : "warn"}>{r.status}</Tag> <TxLink h={r.hash} /></>} />)}
        <a className="link" href="#/activity">All activity</a>
      </div>
    </>
  );
}
