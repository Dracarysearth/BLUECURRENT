import { useMarkets, useVerification } from "../hooks/useChainData";
import { go, type Route } from "../hooks/useRoute";
import { isAddress } from "../lib/format";
import { CurveInsight } from "../components/CurveInsight";
import { MarketPicker } from "../components/MarketPicker";
import { Empty, Notice } from "../components/ui";
import { getCatalog } from "../services/ammora";
import { safeJson } from "../lib/format";

export default function Liquidity({ route }: { route: Route }) {
  const { markets } = useMarkets();
  const ver = useVerification();
  const c = route.params.get("curve") ?? "";
  const m = markets.find((x) => x.curve.toLowerCase() === c.toLowerCase());
  return (
    <>
      <div className="page-head">
        <h1>Liquidity radar</h1>
        <p className="muted">Reserves, curve state and risk flags for one market. “Observed” values are reads from the chain; “calculated” values come from SDK quotes and are labelled as estimates.</p>
      </div>
      <div className="card wide">
        <MarketPicker curve={c} onPick={(x) => go("/liquidity", { curve: typeof x === "string" ? x : x.curve })} />
        {isAddress(c) ? <CurveInsight curve={c} symbol={m?.symbol} decimals={m?.decimals ?? 18} /> : <Empty title="Pick a market to analyse">Liquidity distribution and fee configuration appear here once a curve is selected.</Empty>}
      </div>
      <div className="card wide">
        <h3>Deployment check</h3>
        {ver === "pending" ? <Notice>Checking deployment with the SDK…</Notice> : ver.status === "ok" ? <Notice tone="good">verifyAmmoraV4CoreAtBlock passed at block {ver.block.toString()}.</Notice> : <Notice tone="warn">Deployment check {ver.status}: {ver.message}</Notice>}
        <details><summary>SDK deployment catalog (giwaSepoliaAutoRouteDeployment)</summary><pre className="mono small">{safeJson(getCatalog())}</pre></details>
        <p className="muted small">ALMM / ARL pool analytics are not shown: no pool market is discovered by this app yet, and it never invents pool data.</p>
      </div>
    </>
  );
}
