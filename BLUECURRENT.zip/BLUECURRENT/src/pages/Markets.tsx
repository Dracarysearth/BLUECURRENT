import { useMarkets } from "../hooks/useChainData";
import { go } from "../hooks/useRoute";
import { ago, short } from "../lib/format";
import { AddrLink, Empty, ErrorBox, Spinner, Tag } from "../components/ui";

export default function Markets() {
  const { markets, loading, error, dropped, reload } = useMarkets();
  return (
    <>
      <div className="page-head">
        <h1>Markets</h1>
        <p className="muted">Launch curves indexed by Ammora's Data API on GIWA Sepolia, with token details read from the chain. Open a market for live state, quotes and recent trades.</p>
      </div>
      {loading && <Spinner label="Discovering markets…" />}
      {error && <ErrorBox title="Could not load markets" retry={reload}>{error}</ErrorBox>}
      {!loading && !error && !markets.length && <Empty title="No markets found">The Data API returned no launches for chain 91342.</Empty>}
      <div className="market-grid">
        {markets.map((m) => (
          <article key={m.curve} className="card market">
            <div className="market-top">
              <div><h3>{m.symbol ?? "Unknown"}</h3><span className="muted">{m.name ?? "Unnamed token"}</span></div>
              {m.status !== undefined && <Tag tone="blue">{String(m.status)}</Tag>}
            </div>
            <div className="kv small">
              <div className="row"><span className="k">Token</span><span className="v"><AddrLink a={m.token} /></span></div>
              <div className="row"><span className="k">Curve</span><span className="v"><AddrLink a={m.curve} /></span></div>
              {m.createdAt && <div className="row"><span className="k">Created</span><span className="v">{ago(m.createdAt)}</span></div>}
            </div>
            <div className="actions">
              <button className="btn primary sm" onClick={() => go("/exchange", { curve: m.curve })}>Buy / sell</button>
              <button className="btn ghost sm" onClick={() => go("/market", { curve: m.curve })}>Details</button>
              <button className="btn ghost sm" onClick={() => go("/liquidity", { curve: m.curve })}>Radar</button>
            </div>
          </article>
        ))}
      </div>
      {dropped > 0 && <p className="muted small">{dropped} indexed entries were skipped because they had no recognisable token/curve address.</p>}
      <p className="muted small">Shown: {markets.length}. Addresses like {short(markets[0]?.curve)} are real; nothing on this page is generated.</p>
    </>
  );
}
