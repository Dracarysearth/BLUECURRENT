import { useEffect, useState } from "react";
import { useWallet } from "../hooks/useWallet";
import { loadActivity, reconcile, upsertActivity } from "../lib/activity";
import { WETH } from "../lib/chain";
import { fmtAmount } from "../lib/format";
import { Empty, Notice, Tag, TxLink } from "../components/ui";
import type { ActivityRecord } from "../types";

export default function Activity() {
  const w = useWallet();
  const [rows, setRows] = useState<ActivityRecord[]>([]);

  useEffect(() => {
    if (!w.account) return setRows([]);
    const list = loadActivity(w.account);
    setRows(list);
    // Re-check anything still pending against its on-chain receipt.
    list.filter((r) => r.status === "pending").forEach(async (r) => {
      const next = await reconcile(r, r.direction === "buy" ? r.token : WETH);
      if (next.status !== "pending") {
        upsertActivity(next);
        setRows(loadActivity(w.account!));
      }
    });
  }, [w.account]);

  if (!w.account) return <Empty title="Connect your wallet">Your trade history for this wallet appears here.<br /><button className="btn primary" onClick={w.connect}>Connect wallet</button></Empty>;
  return (
    <>
      <div className="page-head"><h1>Activity</h1><p className="muted">Trades made through BLUECURRENT with this wallet. Status and output amounts come from the actual transaction receipt.</p></div>
      {!rows.length ? <Empty title="No activity yet">Make a trade on the Exchange page and it will appear here.</Empty> : (
        <div className="card wide table-wrap">
          <table>
            <thead><tr><th>Time</th><th>Pair</th><th>Side</th><th>Paid</th><th>Received</th><th>Status</th><th>Tx</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.hash}>
                  <td>{new Date(r.createdAt).toLocaleString()}</td>
                  <td>{r.direction === "buy" ? `WETH/${r.symbol}` : `${r.symbol}/WETH`}</td>
                  <td>{r.direction}</td>
                  <td>{fmtAmount(BigInt(r.amountIn), r.amountInDecimals)} {r.amountInSymbol}</td>
                  <td>{r.amountOut ? `${fmtAmount(BigInt(r.amountOut), r.amountOutDecimals)} ${r.amountOutSymbol}` : "—"}</td>
                  <td><Tag tone={r.status === "confirmed" ? "good" : r.status === "failed" ? "bad" : "warn"}>{r.status}</Tag></td>
                  <td><TxLink h={r.hash} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Notice>History is stored in this browser only. Clearing site data removes it; the transactions stay on-chain.</Notice>
    </>
  );
}
