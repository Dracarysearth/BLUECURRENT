import { useMarkets } from "../hooks/useChainData";
import { go, type Route } from "../hooks/useRoute";
import { isAddress } from "../lib/format";
import { CurveInsight } from "../components/CurveInsight";
import { AddrLink, Empty, Row } from "../components/ui";

export default function MarketDetail({ route }: { route: Route }) {
  const { markets } = useMarkets();
  const c = route.params.get("curve") ?? "";
  if (!isAddress(c)) return <Empty title="No market selected">Open one from <a className="link" href="#/markets">Markets</a>.</Empty>;
  const m = markets.find((x) => x.curve.toLowerCase() === c.toLowerCase());
  return (
    <div className="card wide">
      <div className="card-head"><h1>{m?.symbol ?? "Market"} <span className="muted">{m?.name}</span></h1>
        <div className="actions"><button className="btn primary sm" onClick={() => go("/exchange", { curve: c })}>Buy / sell</button><button className="btn ghost sm" onClick={() => go("/liquidity", { curve: c })}>Liquidity radar</button></div></div>
      {m && <Row k="Token" v={<AddrLink a={m.token} />} />}
      <Row k="Curve" v={<AddrLink a={c} />} />
      <CurveInsight curve={c} symbol={m?.symbol} decimals={m?.decimals ?? 18} />
    </div>
  );
}
