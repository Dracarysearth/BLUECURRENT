import { useCallback, useEffect, useMemo, useState } from "react";
import { erc20Abi } from "../lib/abi";
import { publicClient, REQUIRE_VERIFICATION, WETH, txUrl } from "../lib/chain";
import { applySlippage, fmtAmount, isAddress, parseAmount, short } from "../lib/format";
import { loadActivity, reconcile, upsertActivity } from "../lib/activity";
import { useMarkets, useVerification } from "../hooks/useChainData";
import { useWallet } from "../hooks/useWallet";
import { go, type Route } from "../hooks/useRoute";
import { errMsg, extractWarnings, planSwap, quoteExactIn, readTokenMeta, type QuoteResult, type SwapPlan } from "../services/ammora";
import { MarketPicker } from "../components/MarketPicker";
import { AddrLink, Empty, ErrorBox, Notice, Row, Spinner, Tag, TxLink } from "../components/ui";
import type { ActivityRecord, Approval, Market } from "../types";
import type { Address } from "viem";

const SLIPPAGE = [50, 100, 300];

export default function Exchange({ route }: { route: Route }) {
  const w = useWallet();
  const ver = useVerification();
  const { markets } = useMarkets();
  const curveParam = route.params.get("curve") ?? undefined;
  const curve = curveParam && isAddress(curveParam) ? curveParam : undefined;

  const [token, setToken] = useState<{ address: Address; symbol: string; decimals: number }>();
  const [buy, setBuy] = useState(true); // buy: WETH → token, sell: token → WETH
  const [amount, setAmount] = useState("");
  const [bps, setBps] = useState(100);
  const [customBps, setCustomBps] = useState("");
  const [quote, setQuote] = useState<QuoteResult>();
  const [plan, setPlan] = useState<SwapPlan>();
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [busy, setBusy] = useState<"quote" | "send" | undefined>();
  const [error, setError] = useState<string>();
  const [balances, setBalances] = useState<{ weth?: bigint; token?: bigint }>({});
  const [confirm, setConfirm] = useState(false);
  const [txState, setTxState] = useState<{ hash?: `0x${string}`; text: string; tone: "info" | "good" | "bad" | "warn" }>();
  const [, tick] = useState(0);

  // Resolve the launch token of the selected curve.
  useEffect(() => {
    setToken(undefined); setQuote(undefined); setPlan(undefined); setError(undefined);
    if (!curve) return;
    const m = markets.find((x) => x.curve.toLowerCase() === curve.toLowerCase());
    (async () => {
      try {
        let addr = m?.token;
        if (!addr) throw new Error("Curve not found in discovered markets. Pick one from the list so the token address is known.");
        const meta = await readTokenMeta(addr);
        setToken({ address: addr, symbol: meta.symbol ?? "TOKEN", decimals: meta.decimals });
      } catch (e) {
        setError(errMsg(e));
      }
    })();
  }, [curve, markets]);

  const inSym = buy ? "WETH" : token?.symbol ?? "—";
  const outSym = buy ? token?.symbol ?? "—" : "WETH";
  const inDec = buy ? 18 : token?.decimals ?? 18;
  const outDec = buy ? token?.decimals ?? 18 : 18;
  const amountIn = useMemo(() => parseAmount(amount, inDec), [amount, inDec]);
  const slippage = customBps !== "" ? Math.round(Number(customBps) * 100) : bps;
  const slippageOk = Number.isFinite(slippage) && slippage >= 1 && slippage <= 1000;

  const refreshBalances = useCallback(async () => {
    if (!w.account) return setBalances({});
    try {
      const [weth, tok] = await Promise.all([
        publicClient.readContract({ address: WETH, abi: erc20Abi, functionName: "balanceOf", args: [w.account] }),
        token ? publicClient.readContract({ address: token.address, abi: erc20Abi, functionName: "balanceOf", args: [w.account] }) : Promise.resolve(undefined),
      ]);
      setBalances({ weth, token: tok });
    } catch { /* balances stay unknown */ }
  }, [w.account, token]);
  useEffect(() => { refreshBalances(); }, [refreshBalances]);

  // Any input change invalidates the old quote / plan.
  useEffect(() => { setQuote(undefined); setPlan(undefined); setTxState(undefined); }, [amount, buy, bps, customBps, curve]);
  useEffect(() => { const id = setInterval(() => tick((x) => x + 1), 1000); return () => clearInterval(id); }, []);

  const balIn = buy ? balances.weth : balances.token;
  const insufficient = amountIn !== undefined && balIn !== undefined && amountIn > balIn;
  const verBlocked = REQUIRE_VERIFICATION && ver !== "pending" && ver.status !== "ok";
  const quoteAge = quote ? Math.floor((Date.now() - quote.fetchedAt) / 1000) : 0;
  const stale = quote ? quoteAge > 45 : false;

  async function getQuote() {
    if (!curve || !token || amountIn === undefined) return;
    setBusy("quote"); setError(undefined); setPlan(undefined); setApprovals([]);
    try {
      const q = await quoteExactIn(curve, amountIn, !buy);
      setQuote(q);
      if (w.account && slippageOk) {
        const p = await planSwap({
          curve, amountIn, baseForQuote: !buy, allowPartialFill: !!q.fill?.allowPartialFill,
          slippageBps: slippage, recipient: w.account,
        });
        setPlan(p);
        // SDK approval requirements first; otherwise inspect the allowance ourselves.
        const inToken = buy ? WETH : token.address;
        let need: Approval[] = p.approvals;
        if (!need.length) {
          const allowance = await publicClient.readContract({ address: inToken, abi: erc20Abi, functionName: "allowance", args: [w.account, p.to] });
          need = allowance < amountIn ? [{ token: inToken, spender: p.to, amount: amountIn }] : [];
        } else {
          const checked: Approval[] = [];
          for (const a of need) {
            const al = await publicClient.readContract({ address: a.token, abi: erc20Abi, functionName: "allowance", args: [w.account, a.spender] });
            if (al < a.amount) checked.push(a);
          }
          need = checked;
        }
        setApprovals(need);
      }
    } catch (e) {
      setQuote(undefined);
      setError(`Quote unavailable: ${errMsg(e)}`);
    } finally {
      setBusy(undefined);
    }
  }

  async function execute() {
    if (!w.walletClient || !w.account || !plan || !curve || !token || amountIn === undefined) return;
    setBusy("send"); setConfirm(false);
    try {
      // Exact-amount approvals, one wallet prompt each.
      for (const a of approvals) {
        setTxState({ text: `Approve ${fmtAmount(a.amount, inDec)} ${inSym} in your wallet…`, tone: "info" });
        const h = await w.walletClient.writeContract({ address: a.token, abi: erc20Abi, functionName: "approve", args: [a.spender, a.amount], account: w.account, chain: w.walletClient.chain });
        setTxState({ hash: h, text: "Approval submitted, waiting for confirmation…", tone: "info" });
        const r = await publicClient.waitForTransactionReceipt({ hash: h });
        if (r.status !== "success") throw new Error("Approval transaction failed.");
      }
      // Fresh quote + plan right before signing (the one from before approvals may be stale).
      setTxState({ text: "Refreshing quote and simulating…", tone: "info" });
      const q = await quoteExactIn(curve, amountIn, !buy);
      const p = await planSwap({ curve, amountIn, baseForQuote: !buy, allowPartialFill: !!q.fill?.allowPartialFill, slippageBps: slippage, recipient: w.account });
      await publicClient.call({ account: w.account, to: p.to, data: p.data, value: p.value }); // simulation: reverts surface here
      setTxState({ text: "Confirm the swap in your wallet…", tone: "info" });
      const hash = await w.walletClient.sendTransaction({ account: w.account, chain: w.walletClient.chain, to: p.to, data: p.data, value: p.value });
      const rec: ActivityRecord = {
        hash, account: w.account, curve, token: token.address, symbol: token.symbol,
        direction: buy ? "buy" : "sell", amountIn: amountIn.toString(), amountInDecimals: inDec, amountInSymbol: inSym,
        amountOutDecimals: outDec, amountOutSymbol: outSym, createdAt: Date.now(), status: "pending",
      };
      upsertActivity(rec);
      setTxState({ hash, text: "Submitted. Waiting for the receipt…", tone: "info" });
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      const outToken = buy ? token.address : WETH;
      const done = receipt.status === "success" ? await reconcile(rec, outToken) : { ...rec, status: "failed" as const };
      upsertActivity(done);
      setTxState(
        done.status === "confirmed"
          ? { hash, text: `Confirmed. Received ${fmtAmount(BigInt(done.amountOut ?? "0"), outDec)} ${outSym} (from the receipt's Transfer logs).`, tone: "good" }
          : { hash, text: "The transaction failed on-chain.", tone: "bad" },
      );
      setQuote(undefined); setPlan(undefined);
      refreshBalances();
    } catch (e: any) {
      setTxState({ text: e?.code === 4001 || /rejected|denied/i.test(e?.message ?? "") ? "You rejected the request in your wallet. Nothing was sent." : errMsg(e), tone: "bad" });
    } finally {
      setBusy(undefined);
    }
  }

  const expected = quote?.amountOut;
  const minOut = plan?.minimumOut ?? (expected !== undefined && slippageOk ? applySlippage(expected, slippage) : undefined);
  const warnings = extractWarnings(quote?.raw, plan?.raw);
  const canQuote = !!curve && !!token && amountIn !== undefined && amountIn > 0n && !busy;
  const canSwap = !!plan && !!quote && !stale && !insufficient && !verBlocked && !w.wrongNetwork && !!w.account && !busy;
  const disabledReason =
    !w.account ? "Connect your wallet to trade" : w.wrongNetwork ? "Switch to GIWA Sepolia" : verBlocked ? "Deployment check did not pass" :
    !curve ? "Select a market" : amountIn === undefined ? "Enter an amount" : insufficient ? `Insufficient ${inSym} balance` :
    !quote ? "Get a quote first" : stale ? "Quote expired — refresh" : !plan ? "No executable plan" : undefined;

  return (
    <div className="grid-exchange">
      <section className="card terminal" aria-labelledby="t-h">
        <div className="card-head">
          <h2 id="t-h">Exchange</h2>
          <div className="seg" role="tablist" aria-label="Direction">
            <button role="tab" aria-selected={buy} className={buy ? "on" : ""} onClick={() => setBuy(true)}>Buy</button>
            <button role="tab" aria-selected={!buy} className={!buy ? "on" : ""} onClick={() => setBuy(false)}>Sell</button>
          </div>
        </div>

        <label className="lbl">Market</label>
        <MarketPicker curve={curve} onPick={(m) => go("/exchange", { curve: typeof m === "string" ? m : m.curve })} />

        <div className="swapbox">
          <div className="swaprow">
            <div className="swaphead"><span>You pay</span><button className="linkbtn" disabled={balIn === undefined} onClick={() => balIn !== undefined && setAmount(fmtAmount(balIn, inDec, inDec).replace(/,/g, ""))}>Balance: {w.account ? fmtAmount(balIn, inDec, 6) : "—"}</button></div>
            <div className="amtline">
              <input inputMode="decimal" placeholder="0.0" value={amount} onChange={(e) => setAmount(e.target.value)} aria-label="Amount to pay" />
              <span className="chip">{inSym}</span>
            </div>
          </div>
          <button className="flip" onClick={() => { setBuy(!buy); setAmount(""); }} aria-label="Flip direction">⇅</button>
          <div className="swaprow out">
            <div className="swaphead"><span>You receive (estimate)</span><span>Balance: {w.account ? fmtAmount(buy ? balances.token : balances.weth, outDec, 6) : "—"}</span></div>
            <div className="amtline"><output>{expected !== undefined ? fmtAmount(expected, outDec, 6) : "0.0"}</output><span className="chip">{outSym}</span></div>
          </div>
        </div>

        <div className="slip">
          <span>Slippage</span>
          {SLIPPAGE.map((s) => (
            <button key={s} className={customBps === "" && bps === s ? "pill on" : "pill"} onClick={() => { setBps(s); setCustomBps(""); }}>{s / 100}%</button>
          ))}
          <input className="pill-input" inputMode="decimal" placeholder="Custom %" value={customBps} onChange={(e) => setCustomBps(e.target.value)} aria-label="Custom slippage percent" />
        </div>
        {!slippageOk && <Notice tone="warn">Slippage must be between 0.01% and 10%.</Notice>}

        {error && <ErrorBox title="Cannot continue" retry={canQuote ? getQuote : undefined}>{error}</ErrorBox>}
        {curve && token === undefined && !error && <Spinner label="Reading market…" />}

        <div className="actions">
          <button className="btn ghost" disabled={!canQuote || !slippageOk} onClick={getQuote}>{busy === "quote" ? "Quoting…" : quote ? "Refresh quote" : "Get quote"}</button>
          <button className="btn primary" disabled={!canSwap} onClick={() => setConfirm(true)}>{busy === "send" ? "Working…" : disabledReason ?? (approvals.length ? `Approve & ${buy ? "buy" : "sell"}` : buy ? "Buy" : "Sell")}</button>
        </div>
        {txState && (
          <Notice tone={txState.tone}>
            {txState.text} {txState.hash && <>· <TxLink h={txState.hash} /> · <a className="link" href={txUrl(txState.hash)} target="_blank" rel="noreferrer">Explorer</a></>}
          </Notice>
        )}
      </section>

      <aside className="card preview" aria-labelledby="r-h">
        <h2 id="r-h">Route preview</h2>
        {!quote ? (
          <Empty title="No quote yet">Choose a market, enter an amount and press “Get quote”. Nothing is estimated until the SDK answers.</Empty>
        ) : (
          <>
            <Row k="Market" v={<>{token?.symbol} · <AddrLink a={curve!} /></>} />
            <Row k="Route" v={`${inSym} → ${outSym} via Ammora launch curve`} />
            <Row k="Expected output" v={expected !== undefined ? `${fmtAmount(expected, outDec)} ${outSym}` : "Quote returned without an output field"} />
            <Row k="Price impact" v={quote.priceImpactBps !== undefined ? `${(quote.priceImpactBps / 100).toFixed(2)}%` : "Not provided by the SDK for this quote"} />
            <Row k="Curve fee" v={quote.feeAmount !== undefined ? `${fmtAmount(quote.feeAmount, inDec)} ${inSym}` : "Not provided"} />
            <Row k="Slippage tolerance" v={slippageOk ? `${slippage / 100}%` : "—"} />
            <Row k="Minimum received" v={minOut !== undefined ? `${fmtAmount(minOut, outDec)} ${outSym}` : "—"} hint={plan?.minimumOut !== undefined ? "From the SDK plan" : "Calculated from the quote with BigInt math"} />
            <Row k="Approval" v={!w.account ? "Connect wallet to check" : plan ? (approvals.length ? <Tag tone="warn">{approvals.length} exact-amount approval needed</Tag> : <Tag tone="good">Not required</Tag>) : "—"} />
            <Row k="Final fill" v={quote.fill ? (quote.fill.allowPartialFill ? <Tag tone="warn">Graduation boundary: partial fill, unused input is returned</Tag> : <Tag tone="good">{quote.fill.kind ?? "Full fill"}</Tag>) : "—"} />
            <Row k="Quote freshness" v={<Tag tone={stale ? "bad" : "good"}>{stale ? `Expired (${quoteAge}s)` : `${quoteAge}s old · block ${quote.block}`}</Tag>} />
            <Row k="Deadline" v={plan ? `${new Date(Number(plan.deadline) * 1000).toLocaleTimeString()} (20 min)` : "Set when a plan is built"} />
            <Row k="Network fee" v="Paid in ETH; the wallet shows the exact estimate" />
            {warnings.map((m, i) => <Notice key={i} tone="warn">{m}</Notice>)}
            <p className="muted small">Output is a read-only quote. The wallet transaction is simulated again right before signing.</p>
          </>
        )}
      </aside>

      {confirm && plan && (
        <div className="modal-back" role="dialog" aria-modal="true" aria-label="Confirm swap" onClick={() => setConfirm(false)}>
          <div className="modal card" onClick={(e) => e.stopPropagation()}>
            <h2>Confirm {buy ? "buy" : "sell"}</h2>
            <Row k="You pay" v={`${amount} ${inSym}`} />
            <Row k="You receive (est.)" v={`${fmtAmount(expected, outDec)} ${outSym}`} />
            <Row k="Minimum received" v={`${fmtAmount(minOut, outDec)} ${outSym}`} />
            <Row k="Contract" v={<AddrLink a={plan.to} />} />
            {approvals.map((a, i) => <Notice key={i} tone="warn">First you will approve exactly {fmtAmount(a.amount, inDec)} {inSym} for <AddrLink a={a.spender} />.</Notice>)}
            <div className="actions">
              <button className="btn ghost" onClick={() => setConfirm(false)}>Cancel</button>
              <button className="btn primary" onClick={execute}>Sign in wallet</button>
            </div>
          </div>
        </div>
      )}
      <RecentOnExchange account={w.account} />
    </div>
  );
}

function RecentOnExchange({ account }: { account?: Address }) {
  const recs = account ? loadActivity(account).slice(0, 3) : [];
  if (!recs.length) return null;
  return (
    <section className="card wide">
      <h2>Your latest trades</h2>
      {recs.map((r) => <Row key={r.hash} k={`${r.direction.toUpperCase()} ${r.symbol}`} v={<><Tag tone={r.status === "confirmed" ? "good" : r.status === "failed" ? "bad" : "warn"}>{r.status}</Tag> <TxLink h={r.hash} /></>} />)}
    </section>
  );
}
