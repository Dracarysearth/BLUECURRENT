import type { ReactNode } from "react";
import { addressUrl, txUrl } from "../lib/chain";
import { short } from "../lib/format";

export const Spinner = ({ label }: { label?: string }) => (
  <span className="spin-wrap"><span className="spinner" aria-hidden />{label && <span>{label}</span>}</span>
);

export const Empty = ({ title, children }: { title: string; children?: ReactNode }) => (
  <div className="empty"><strong>{title}</strong>{children && <p>{children}</p>}</div>
);

export const ErrorBox = ({ title = "Something went wrong", children, retry }: { title?: string; children?: ReactNode; retry?: () => void }) => (
  <div className="notice bad" role="alert">
    <strong>{title}</strong>
    {children && <p>{children}</p>}
    {retry && <button className="btn ghost sm" onClick={retry}>Try again</button>}
  </div>
);

export const Notice = ({ tone = "info", children }: { tone?: "info" | "warn" | "bad" | "good"; children: ReactNode }) => (
  <div className={`notice ${tone}`}>{children}</div>
);

export const Row = ({ k, v, hint }: { k: string; v: ReactNode; hint?: string }) => (
  <div className="row" title={hint}><span className="k">{k}</span><span className="v">{v}</span></div>
);

export const Tag = ({ tone = "muted", children }: { tone?: "muted" | "good" | "warn" | "bad" | "blue"; children: ReactNode }) => (
  <span className={`tag ${tone}`}>{children}</span>
);

export const AddrLink = ({ a }: { a: string }) => (
  <a className="mono link" href={addressUrl(a)} target="_blank" rel="noreferrer">{short(a)}</a>
);
export const TxLink = ({ h }: { h: string }) => (
  <a className="mono link" href={txUrl(h)} target="_blank" rel="noreferrer">{short(h, 6)}</a>
);
