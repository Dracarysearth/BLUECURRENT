import { useBlock } from "../hooks/useChainData";
import { useWallet } from "../hooks/useWallet";
import { short } from "../lib/format";
import { Logo } from "./Logo";

export const NAV = [
  ["/exchange", "Exchange"],
  ["/markets", "Markets"],
  ["/liquidity", "Liquidity"],
  ["/portfolio", "Portfolio"],
  ["/activity", "Activity"],
] as const;

export function Header({ path }: { path: string }) {
  const w = useWallet();
  const block = useBlock();
  return (
    <header className="header">
      <a href="#/exchange" className="brand" aria-label="BLUECURRENT home"><Logo /></a>
      <nav className="nav" aria-label="Main">
        {NAV.map(([p, label]) => (
          <a key={p} href={`#${p}`} className={path === p ? "active" : ""} aria-current={path === p ? "page" : undefined}>{label}</a>
        ))}
      </nav>
      <div className="head-right">
        <span className="badge net" title="Network">
          <i className={w.wrongNetwork ? "dot warn" : "dot"} />GIWA Sepolia{block !== undefined && <em>#{block.toString()}</em>}
        </span>
        {w.account ? (
          <>
            {w.wrongNetwork && <button className="btn warn sm" onClick={w.switchNetwork}>Switch network</button>}
            <button className="btn ghost sm mono" onClick={w.disconnect} title="Disconnect">{short(w.account)} · Disconnect</button>
          </>
        ) : (
          <button className="btn primary sm" onClick={w.connect} disabled={w.connecting}>{w.connecting ? "Connecting…" : "Connect wallet"}</button>
        )}
      </div>
    </header>
  );
}
