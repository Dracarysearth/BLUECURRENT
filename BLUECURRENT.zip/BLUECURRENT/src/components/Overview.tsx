import { useMarkets } from "../hooks/useChainData";
import { go } from "../hooks/useRoute";
import { ago } from "../lib/format";
import { Logo } from "./Logo";
import { Spinner } from "./ui";

/** Hero + market overview for the home (Exchange) route. Only real, discovered data. */
export function Hero() {
  return (
    <section className="hero">
      <Logo big />
      <h1>Discover liquidity. Trade smarter.</h1>
      <p>Swap on Ammora launch curves, check reserves and price impact first, then sign from your own wallet.</p>
    </section>
  );
}

export function Overview() {
  const { markets, loading, error } = useMarkets();
  return (
    <section className="card wide">
      <div className="card-head"><h2>Market overview</h2><a className="link" href="#/markets">All markets</a></div>
      {loading ? <Spinner label="Loading markets…" /> : error ? <p className="muted">Market list unavailable right now.</p> : (
        <>
          <p className="stat"><strong>{markets.length}</strong> launch markets discovered on GIWA Sepolia</p>
          <div className="mini-list">
            {markets.slice(0, 6).map((m) => (
              <button key={m.curve} className="mini" onClick={() => go("/exchange", { curve: m.curve })}>
                <b>{m.symbol ?? "?"}</b><span>{m.name ?? ""}</span>{m.createdAt && <em>{ago(m.createdAt)}</em>}
              </button>
            ))}
          </div>
          <p className="muted small">Liquidity statistics per market are on the <a className="link" href="#/liquidity">Liquidity radar</a>; this overview does not show totals it cannot verify.</p>
        </>
      )}
    </section>
  );
}
