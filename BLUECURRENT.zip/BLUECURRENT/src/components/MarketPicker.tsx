import { useMarkets } from "../hooks/useChainData";
import { isAddress, short } from "../lib/format";
import type { Market } from "../types";

/** Select a discovered market or paste a curve address. */
export function MarketPicker({ curve, onPick }: { curve?: string; onPick: (m: Market | string) => void }) {
  const { markets, loading } = useMarkets();
  return (
    <div className="picker">
      <select
        value={markets.find((m) => m.curve === curve)?.curve ?? ""}
        onChange={(e) => {
          const m = markets.find((x) => x.curve === e.target.value);
          if (m) onPick(m);
        }}
        aria-label="Select market"
      >
        <option value="">{loading ? "Loading markets…" : markets.length ? "Select a market" : "No markets found"}</option>
        {markets.map((m) => (
          <option key={m.curve} value={m.curve}>{m.symbol ?? "?"} · {m.name ?? short(m.token)} · {short(m.curve)}</option>
        ))}
      </select>
      <input
        className="mono"
        placeholder="…or paste a curve address 0x…"
        defaultValue={curve && !markets.find((m) => m.curve === curve) ? curve : ""}
        onChange={(e) => isAddress(e.target.value.trim()) && onPick(e.target.value.trim())}
        aria-label="Curve address"
      />
    </div>
  );
}
