import { useEffect, useState } from "react";
import type { Address } from "viem";
import { fmtAmount, safeJson } from "../lib/format";
import { useVerification } from "../hooks/useChainData";
import { errMsg, quoteExactIn, readCurveState, readRecentSwaps, type QuoteResult, type SwapEvent } from "../services/ammora";
import { Empty, Notice, Row, Spinner, Tag, TxLink } from "./ui";

const PROBE = 10n ** 15n; // 0.001 WETH probe quote

const flat = (o: unknown, prefix = ""): [string, string][] => {
  if (o === null || typeof o !== "object") return [[prefix, String(o)]];
  return Object.entries(o as Record<string, unknown>).flatMap(([k, v]) =>
    v !== null && typeof v === "object" && !Array.isArray(v) ? flat(v, prefix ? `${prefix}.${k}` : k) : [[prefix ? `${prefix}.${k}` : k, typeof v === "bigint" ? v.toString() : Array.isArray(v) ? safeJson(v, 0) : String(v)]],
  );
};

export function CurveInsight({ curve, symbol, decimals = 18 }: { curve: Address; symbol?: string; decimals?: number }) {
  const ver = useVerification();
  const [st, setSt] = useState<{ block: bigint; state: Record<string, unknown> }>();
  const [probe, setProbe] = useState<QuoteResult | "unavailable">();
  const [swaps, setSwaps] = useState<SwapEvent[] | string>();
  const [err, setErr] = useState<string>();

  useEffect(() => {
    let live = true;
    setSt(undefined); setProbe(undefined); setSwaps(undefined); setErr(undefined);
    readCurveState(curve).then((s) => live && setSt(s)).catch((e) => live && setErr(errMsg(e)));
    quoteExactIn(curve, PROBE, false).then((q) => live && setProbe(q)).catch(() => live && setProbe("unavailable"));
    readRecentSwaps(curve).then((s) => live && setSwaps(s)).catch((e) => live && setSwaps(errMsg(e)));
    return () => { live = false; };
  }, [curve]);

  if (err) return <Notice tone="bad">Could not read live curve state: {err}</Notice>;
  if (!st) return <Spinner label="Reading on-chain state…" />;

  const status = st.state.status;
  const rows = flat(st.state);
  const price = typeof probe === "object" && probe.amountOut && probe.amountOut > 0n ? (Number(PROBE) / Number(probe.amountOut)) : undefined; // display only, never used for execution
  const risks: { tone: "bad" | "warn" | "good"; text: string }[] = [];
  if (Number(status) === 2) risks.push({ tone: "warn", text: "Curve is ready to migrate. Final buys fill only up to the graduation boundary." });
  if (probe === "unavailable") risks.push({ tone: "bad", text: "The SDK could not quote this curve. Trading is disabled until it can." });
  if (typeof probe === "object" && probe.fill?.allowPartialFill) risks.push({ tone: "warn", text: "A small buy already reaches the graduation boundary (very little room left on the curve)." });
  if (typeof probe === "object" && (probe.priceImpactBps ?? 0) > 300) risks.push({ tone: "warn", text: `A 0.001 WETH probe moves price by ${(probe.priceImpactBps! / 100).toFixed(2)}%: thin liquidity.` });
  if (ver !== "pending" && ver.status !== "ok") risks.push({ tone: "warn", text: "Deployment check did not pass; reads may not be trustworthy." });
  if (!risks.length) risks.push({ tone: "good", text: "No risk flags from the checks this app can run. This is not a safety guarantee." });

  return (
    <>
      <h3>Observed on-chain <Tag tone="blue">read at block {st.block.toString()}</Tag></h3>
      <div className="kv">{rows.map(([k, v]) => <Row key={k} k={k} v={<span className="mono wrap">{v}</span>} />)}</div>

      <h3>Calculated estimates <Tag tone="warn">not on-chain facts</Tag></h3>
      {probe === undefined ? <Spinner label="Probing with a 0.001 WETH quote…" /> : probe === "unavailable" ? <Empty title="No quote available" /> : (
        <>
          <Row k="Effective price (incl. fee)" v={price ? `${price.toPrecision(6)} WETH per ${symbol ?? "token"}` : "—"} hint="WETH in / tokens out for a 0.001 WETH buy quote" />
          <Row k="Tokens per 0.001 WETH" v={probe.amountOut !== undefined ? `${fmtAmount(probe.amountOut, decimals)} ${symbol ?? ""}` : "—"} />
          <Row k="Probe price impact" v={probe.priceImpactBps !== undefined ? `${(probe.priceImpactBps / 100).toFixed(2)}%` : "Not provided"} />
        </>
      )}

      <h3>Risk indicators</h3>
      {risks.map((r, i) => <Notice key={i} tone={r.tone}>{r.text}</Notice>)}

      <h3>Recent trades <Tag tone="blue">curve Swap events, last ~9k blocks</Tag></h3>
      {swaps === undefined ? <Spinner /> : typeof swaps === "string" ? <Notice tone="warn">Trade history unavailable: {swaps}</Notice> : !swaps.length ? <Empty title="No trades in the scanned range" /> : (
        swaps.slice(0, 8).map((s) => <Row key={s.hash + s.block} k={`Block ${s.block}`} v={<><TxLink h={s.hash} /> <span className="mono small muted">{safeJson(s.args, 0).slice(0, 90)}</span></>} />)
      )}
    </>
  );
}
