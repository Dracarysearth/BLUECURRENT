export function LogoMark({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" role="img" aria-label="BLUECURRENT logo">
      <defs>
        <linearGradient id="bcg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3de0ff" />
          <stop offset="1" stopColor="#2f6bff" />
        </linearGradient>
      </defs>
      <rect x="1" y="1" width="38" height="38" rx="11" fill="#07122b" stroke="url(#bcg)" strokeWidth="1.5" />
      <path d="M6 26c4.5-10 8 6 13-3.5S28 27 34 14" fill="none" stroke="url(#bcg)" strokeWidth="3.2" strokeLinecap="round" />
      <path d="M6 31c4-6 7.5 3 12-1.5s8-1 11-6" fill="none" stroke="#3de0ff" strokeOpacity=".35" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ big = false }: { big?: boolean }) {
  return (
    <span className={big ? "logo logo-big" : "logo"}>
      <LogoMark size={big ? 56 : 34} />
      <span className="logo-word">BLUECURRENT</span>
    </span>
  );
}
