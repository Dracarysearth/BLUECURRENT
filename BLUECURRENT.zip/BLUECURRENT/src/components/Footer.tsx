export function Footer() {
  return (
    <footer className="footer">
      <p>Independent community-built application powered by the Ammora SDK on GIWA.</p>
      <p className="muted">Testnet software, no audit. Never use real funds. Not financial advice.</p>
    </footer>
  );
}
