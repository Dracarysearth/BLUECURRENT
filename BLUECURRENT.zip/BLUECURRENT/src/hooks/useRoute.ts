import { useEffect, useState } from "react";

export type Route = { path: string; params: URLSearchParams };

const parse = (): Route => {
  const raw = window.location.hash.replace(/^#/, "") || "/exchange";
  const [path, q = ""] = raw.split("?");
  return { path: path || "/exchange", params: new URLSearchParams(q) };
};

export function useRoute(): Route {
  const [r, setR] = useState<Route>(parse);
  useEffect(() => {
    const f = () => setR(parse());
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);
  return r;
}

export const go = (path: string, params?: Record<string, string>) => {
  const q = params ? "?" + new URLSearchParams(params).toString() : "";
  window.location.hash = path + q;
};
