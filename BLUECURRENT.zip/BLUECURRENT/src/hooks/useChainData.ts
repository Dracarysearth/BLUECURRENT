import { useEffect, useState } from "react";
import { fetchMarkets, readTokenMeta, verifyDeployment, type Verification } from "../services/ammora";
import { publicClient } from "../lib/chain";
import type { Market } from "../types";

let verifyP: Promise<Verification> | undefined;
export function useVerification() {
  const [v, setV] = useState<Verification | "pending">("pending");
  useEffect(() => {
    verifyP ??= verifyDeployment();
    verifyP.then(setV);
  }, []);
  return v;
}

export function useBlock() {
  const [b, setB] = useState<bigint>();
  useEffect(() => {
    let live = true;
    const tick = () => publicClient.getBlockNumber().then((n) => live && setB(n)).catch(() => {});
    tick();
    const id = setInterval(tick, 15_000);
    return () => {
      live = false;
      clearInterval(id);
    };
  }, []);
  return b;
}

type MarketsState = { loading: boolean; error?: string; markets: Market[]; dropped: number };
let cache: MarketsState | undefined;

export function useMarkets(): MarketsState & { reload: () => void } {
  const [s, setS] = useState<MarketsState>(cache ?? { loading: true, markets: [], dropped: 0 });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (cache && n === 0) return;
    let live = true;
    setS((p) => ({ ...p, loading: true, error: undefined }));
    (async () => {
      try {
        const { markets, dropped } = await fetchMarkets(40);
        // Fill missing name/symbol/decimals straight from the token contracts.
        const filled = await Promise.all(
          markets.map(async (m) => {
            const meta = await readTokenMeta(m.token).catch(() => undefined);
            return { ...m, name: m.name ?? meta?.name, symbol: m.symbol ?? meta?.symbol, decimals: meta?.decimals ?? 18 };
          }),
        );
        cache = { loading: false, markets: filled, dropped };
        if (live) setS(cache);
      } catch (e: any) {
        if (live) setS({ loading: false, markets: [], dropped: 0, error: String(e?.shortMessage ?? e?.message ?? e).slice(0, 240) });
      }
    })();
    return () => {
      live = false;
    };
  }, [n]);
  return { ...s, reload: () => { cache = undefined; setN((x) => x + 1); } };
}
