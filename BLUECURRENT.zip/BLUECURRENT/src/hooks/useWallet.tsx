import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { createWalletClient, custom, type Address, type WalletClient } from "viem";
import { EXPLORER_URL, giwaSepolia, RPC_URL } from "../lib/chain";

type Eip1193 = {
  request: (a: { method: string; params?: unknown[] }) => Promise<any>;
  on?: (e: string, f: (...a: any[]) => void) => void;
  removeListener?: (e: string, f: (...a: any[]) => void) => void;
  isMetaMask?: boolean;
  providers?: Eip1193[];
};

function getProvider(): Eip1193 | undefined {
  const eth = (window as any).ethereum as Eip1193 | undefined;
  if (!eth) return undefined;
  return eth.providers?.find((p) => p.isMetaMask) ?? eth;
}

type Ctx = {
  account?: Address;
  chainId?: number;
  wrongNetwork: boolean;
  hasProvider: boolean;
  connecting: boolean;
  error?: string;
  walletClient?: WalletClient;
  connect: () => Promise<void>;
  disconnect: () => void;
  switchNetwork: () => Promise<void>;
};

const WalletCtx = createContext<Ctx | null>(null);
export const useWallet = () => {
  const c = useContext(WalletCtx);
  if (!c) throw new Error("useWallet outside WalletProvider");
  return c;
};

const FLAG = "bc:connected";

export function WalletProvider({ children }: { children: ReactNode }) {
  const [account, setAccount] = useState<Address>();
  const [chainId, setChainId] = useState<number>();
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string>();
  const provider = getProvider();

  const readChain = useCallback(async () => {
    const p = getProvider();
    if (!p) return;
    setChainId(parseInt(await p.request({ method: "eth_chainId" }), 16));
  }, []);

  // Restore a previous session without prompting.
  useEffect(() => {
    const p = getProvider();
    if (!p || localStorage.getItem(FLAG) !== "1") return;
    p.request({ method: "eth_accounts" })
      .then((a: string[]) => {
        if (a[0]) setAccount(a[0] as Address);
        return readChain();
      })
      .catch(() => {});
  }, [readChain]);

  // Account + chain change events.
  useEffect(() => {
    const p = getProvider();
    if (!p?.on) return;
    const onAccounts = (a: string[]) => {
      if (!a.length) {
        setAccount(undefined);
        localStorage.removeItem(FLAG);
      } else setAccount(a[0] as Address);
    };
    const onChain = (id: string) => setChainId(parseInt(id, 16));
    p.on("accountsChanged", onAccounts);
    p.on("chainChanged", onChain);
    return () => {
      p.removeListener?.("accountsChanged", onAccounts);
      p.removeListener?.("chainChanged", onChain);
    };
  }, []);

  const switchNetwork = useCallback(async () => {
    const p = getProvider();
    if (!p) return;
    const hexId = `0x${giwaSepolia.id.toString(16)}`;
    try {
      await p.request({ method: "wallet_switchEthereumChain", params: [{ chainId: hexId }] });
    } catch (e: any) {
      if (e?.code === 4902 || /unrecognized|not added/i.test(e?.message ?? "")) {
        await p.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: hexId,
              chainName: "GIWA Sepolia",
              nativeCurrency: giwaSepolia.nativeCurrency,
              rpcUrls: [RPC_URL],
              blockExplorerUrls: [EXPLORER_URL],
            },
          ],
        });
      } else throw e;
    }
    await readChain();
  }, [readChain]);

  const connect = useCallback(async () => {
    const p = getProvider();
    setError(undefined);
    if (!p) {
      setError("No browser wallet found. Install MetaMask to connect.");
      return;
    }
    setConnecting(true);
    try {
      const a: string[] = await p.request({ method: "eth_requestAccounts" });
      setAccount(a[0] as Address);
      localStorage.setItem(FLAG, "1");
      await readChain();
      const id = parseInt(await p.request({ method: "eth_chainId" }), 16);
      if (id !== giwaSepolia.id) await switchNetwork().catch(() => {});
    } catch (e: any) {
      setError(e?.code === 4001 ? "Connection request was rejected." : String(e?.message ?? e).slice(0, 200));
    } finally {
      setConnecting(false);
    }
  }, [readChain, switchNetwork]);

  const disconnect = useCallback(() => {
    setAccount(undefined);
    localStorage.removeItem(FLAG);
    // Best effort: ask the wallet to drop the site permission (supported by MetaMask).
    getProvider()?.request({ method: "wallet_revokePermissions", params: [{ eth_accounts: {} }] }).catch(() => {});
  }, []);

  const walletClient = useMemo(
    () => (account && provider ? createWalletClient({ account, chain: giwaSepolia, transport: custom(provider) }) : undefined),
    [account, provider],
  );

  const value: Ctx = {
    account,
    chainId,
    wrongNetwork: !!account && chainId !== undefined && chainId !== giwaSepolia.id,
    hasProvider: !!provider,
    connecting,
    error,
    walletClient,
    connect,
    disconnect,
    switchNetwork: () => switchNetwork().catch((e) => setError(String(e?.message ?? e).slice(0, 200))),
  };
  return <WalletCtx.Provider value={value}>{children}</WalletCtx.Provider>;
}
